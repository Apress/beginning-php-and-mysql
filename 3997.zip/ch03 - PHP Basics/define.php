<?php

define("PI", 3.141592);

print "The value of pi is ".PI.".<br />";
$pi2 = 2 * PI;
print "Pi doubled equals $pi2."; 


?>