<?php
   $heavyweight = "Lennox Lewis";
   $lightweight = "Floyd Mayweather";
   echo $heavyweight, " and ", $lightweight, " are great fighters.";
?>