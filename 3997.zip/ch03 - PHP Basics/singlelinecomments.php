<?php
     // Title: My PHP program
     // Author: Jason
     print "This is a PHP program";
?>