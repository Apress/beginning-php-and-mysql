<?php

   $states = array("Alabama", "Alaska", "Arizona", "Arkansas", 
                   "California", "Colorado", "Connecticut");
   $subset = array_slice($states, 4);
     print_r($subset);

?>