<?php

$states = array("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Connecticut");
$subset = array_splice($states, 4);
print_r($states);
print_r($subset);

?>