<?php

$states = array("Delaware","Pennsylvania","New Jersey");
arsort($states);
print_r($states);

?>