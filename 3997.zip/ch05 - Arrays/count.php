<?php

$garden = array("cabbage", "peppers", "turnips", "carrots");
echo count($garden);

?>