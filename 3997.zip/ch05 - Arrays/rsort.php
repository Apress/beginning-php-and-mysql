<?php

$states = array("Ohio","Florida","Massachusetts","Montana");
sort($states);
print_r($states);

?>