<?php
   $advertisement = "Coffee at 'Caf� Fran�aise' costs $2.25.";
   echo  htmlentities($advertisement);
?>