<?php
   $url = "sales@example.com"; 
   echo ltrim(strstr($url, "@"),"@");
?>