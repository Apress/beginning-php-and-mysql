<?php
   $sentence = "the newest version of PHP was released today!";
   echo ucfirst($sentence);
?>