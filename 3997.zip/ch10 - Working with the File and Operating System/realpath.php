<?php
     $imgPath = "../../images/cover.gif";
     $absolutePath = realpath($imgPath); 
     // Returns /www/htdocs/book/images/cover.gif
?>