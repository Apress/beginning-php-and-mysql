<?php

$futuredate = strtotime("45 days");
echo date("F d, Y", $futuredate);

?>