<?php

$date = new Date();
$date->setDMY(4,1,2005);
echo $date->getISOWeekOfYear();

?>