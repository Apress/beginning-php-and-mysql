<?php

$lastmod = date(�F d, Y h:i:sa�, getlastmod());
echo �Page last modified on $lastmod�;

?>