<?php
   $pswd = "567hejk39";

   /* Open the dictionary. Note that the dictionary 
      filename does NOT include the extension.
   */
   $dictionary = crack_opendict('/usr/lib/cracklib_dict');

   // Check password for guessability
   $check = crack_check($dictionary, $pswd);

   // Retrieve outcome
   echo crack_getlastmessage();

   // Close dictionary
   crack_closedict($dictionary);
?>