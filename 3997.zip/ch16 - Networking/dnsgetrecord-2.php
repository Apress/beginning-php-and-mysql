<?php
   $result = dns_get_record("example.com","DNS_CNAME");
   print_r($result);
?>