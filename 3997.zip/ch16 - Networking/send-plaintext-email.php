<?php
   mail("test@example.com", "This is a subject", "This is the mail body");
?>