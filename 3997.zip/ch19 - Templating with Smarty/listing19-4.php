<?php
   require("Smarty.class.php");
   $smarty = new Smarty;

   // Assign two Smarty variables
   $smarty->assign("name", "Jason Gilmore");
   $smarty->assign("title", "Smarty Rocks!");

   // Retrieve and output the template
   $smarty->display("index.tpl");
?>