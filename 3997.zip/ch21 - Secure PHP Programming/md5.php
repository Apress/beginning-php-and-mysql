<?php
   $val = "secret";
   $hash_val = md5 ($val);
   // $hash_val = "c1ab6fb9182f16eed935ba19aa830788";
?>