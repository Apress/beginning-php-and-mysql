<?php 
    echo $this->render('header.phtml');
?>

<div id="header">Next Chess Club Meeting: April 12</div>

<p>
Welcome to our Chess Club's Web site! We're a bunch of chess enthusiasts
who travel the globe in search of worthy opponents. Join us at our next
meeting, held at the coffee shop on the corner of Third and Neil
each Tuesday at 6 p.m.
</p>

<?php
    echo $this->render('footer.phtml');
?>
