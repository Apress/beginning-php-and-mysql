<?php
    echo $this->render('header.phtml');
?>

<div id="header">About Our Chess Club</div>

<p>
    Founded: 1997<br />
    City: Columbus, Ohio<br />
    Where we meet: Cup of Love, corner of Third and Neil<br />
    When we meet: Each Tuesday at 6 p.m.<br />
    Notes: Bring your board and pieces if you have them!
</p>

<?php
    echo $this->render('footer.phtml');
?>
